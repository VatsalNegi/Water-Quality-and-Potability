import streamlit as st
import numpy as np
import joblib
import time

# ==========================
# 📁 Load Model and Scaler
# ==========================
MODEL_PATH = 'C:/Users/vatsa/OneDrive/Desktop/Water Quality & Potability/app/random_forest_model.pkl'
SCALER_PATH = 'C:/Users/vatsa/OneDrive/Desktop/Water Quality & Potability/app/scaler.pkl'

model = joblib.load(MODEL_PATH)
scaler = joblib.load(SCALER_PATH)

# ==========================
# 💠 Page Setup
# ==========================
st.set_page_config(page_title="💧 Water Potability Analyzer", layout="wide")

# --- Custom CSS ---
st.markdown("""
<style>
/* Background gradient */
[data-testid="stAppViewContainer"] {
    background: linear-gradient(180deg, #E3F2FD 0%, #BBDEFB 100%);
}

/* Card container */
.main {
    background-color: rgba(255, 255, 255, 0.8);
    border-radius: 25px;
    padding: 2rem;
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
    backdrop-filter: blur(8px);
}

/* Title */
h1 {
    text-align: center;
    color: #0D47A1;
    font-weight: 800;
    font-family: 'Segoe UI';
}

/* Buttons */
.stButton>button {
    background: linear-gradient(90deg, #42A5F5, #1E88E5);
    color: white;
    border-radius: 12px;
    padding: 12px 30px;
    font-size: 18px;
    border: none;
    font-weight: 600;
    box-shadow: 0 3px 8px rgba(66,165,245,0.4);
    transition: 0.3s;
}
.stButton>button:hover {
    transform: scale(1.06);
    box-shadow: 0 5px 15px rgba(30,136,229,0.5);
}

/* Result card */
.result-card {
    background: rgba(255,255,255,0.6);
    border: 2px solid #BBDEFB;
    padding: 20px;
    border-radius: 15px;
    backdrop-filter: blur(10px);
    margin-top: 1rem;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

/* Confidence bar */
.conf-bar {
    height: 18px;
    border-radius: 10px;
    background: #E3F2FD;
    overflow: hidden;
    margin-top: 0.5rem;
}
.conf-fill {
    height: 100%;
    background: linear-gradient(90deg, #42A5F5, #1E88E5);
}

/* Footer */
.footer {
    text-align: center;
    margin-top: 2rem;
    color: #1565C0;
    font-size: 14px;
}
</style>
""", unsafe_allow_html=True)

# ==========================
# 🧠 App Header
# ==========================
st.markdown("<h1>💧 Smart Water Potability Predictor</h1>", unsafe_allow_html=True)
st.markdown("<h5 style='text-align:center;color:#1976D2;'>AI-powered analysis for safe drinking water assessment 🧪</h5>", unsafe_allow_html=True)
st.divider()

# ==========================
# 🧾 Input Section
# ==========================
st.subheader("🔍 Enter Water Quality Parameters")

col1, col2, col3 = st.columns(3)
with col1:
    ph = st.number_input("pH", min_value=0.0, max_value=14.0, value=7.0)
    hardness = st.number_input("Hardness", min_value=0.0, value=150.0)
    solids = st.number_input("Solids (ppm)", min_value=0.0, value=20000.0)
with col2:
    chloramines = st.number_input("Chloramines", min_value=0.0, value=7.0)
    sulfate = st.number_input("Sulfate", min_value=0.0, value=330.0)
    conductivity = st.number_input("Conductivity", min_value=0.0, value=400.0)
with col3:
    organic_carbon = st.number_input("Organic Carbon", min_value=0.0, value=10.0)
    trihalomethanes = st.number_input("Trihalomethanes", min_value=0.0, value=60.0)
    turbidity = st.number_input("Turbidity", min_value=0.0, value=3.0)

st.divider()

# ==========================
# 🔮 Prediction Logic
# ==========================
if st.button("🔮 Predict Potability"):
    features = np.array([[ph, hardness, solids, chloramines, sulfate, conductivity,
                          organic_carbon, trihalomethanes, turbidity]])
    scaled_features = scaler.transform(features)
    prediction = model.predict(scaled_features)[0]
    proba = model.predict_proba(scaled_features)[0]

    with st.spinner("Analyzing sample... 💧"):
        time.sleep(1.5)

    st.divider()
    st.subheader("📋 Prediction Report")

    if prediction == 1:
        st.markdown("<h3 style='color:#2E7D32;'>✅ SAFE to Drink</h3>", unsafe_allow_html=True)
        st.markdown("""
        <div class='result-card'>
        <h4>💧 Analysis Summary</h4>
        <ul>
            <li>✅ pH and turbidity are within safe limits.</li>
            <li>✅ Organic compounds are within WHO standards.</li>
            <li>💡 Suggestion: Continue periodic monitoring for consistency.</li>
            <li>🧊 Use RO filtration for enhanced taste and safety.</li>
        </ul>
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown("<h3 style='color:#C62828;'>🚫 NOT SAFE to Drink</h3>", unsafe_allow_html=True)
        st.markdown("""
        <div class='result-card'>
        <h4>⚠️ Risk Report</h4>
        <ul>
            <li>⚠️ High levels of solids or organic compounds detected.</li>
            <li>⚠️ Possible microbial or chemical contamination.</li>
            <li>💡 Suggestion: Use advanced RO+UV filtration before consumption.</li>
            <li>🧪 Retest after treatment to confirm potability.</li>
        </ul>
        </div>
        """, unsafe_allow_html=True)

    # ==========================
    # 🎯 Confidence Meter
    # ==========================
    confidence = proba[1] if prediction == 1 else proba[0]
    st.markdown("#### 🎯 Model Confidence:")
    st.markdown(f"<b>{round(confidence * 100, 2)}%</b>", unsafe_allow_html=True)
    st.markdown(f"<div class='conf-bar'><div class='conf-fill' style='width:{confidence*100}%;'></div></div>", unsafe_allow_html=True)

    # ==========================
    # 📊 Quick Parameter Summary
    # ==========================
    st.divider()
    st.subheader("📊 Entered Water Parameters")

    cols = st.columns(3)
    params = [("🌡️ pH", ph), ("💎 Hardness", hardness), ("🧪 Solids", solids),
              ("☣️ Chloramines", chloramines), ("🧫 Sulfate", sulfate),
              ("⚡ Conductivity", conductivity), ("🧬 Organic Carbon", organic_carbon),
              ("🧴 Trihalomethanes", trihalomethanes), ("🌫️ Turbidity", turbidity)]

    for i, (label, val) in enumerate(params):
        with cols[i % 3]:
            st.markdown(f"""
            <div class='metric-card'>
                <h5>{label}</h5>
                <p style='font-size:20px;color:#1565C0;font-weight:600;'>{val}</p>
            </div>
            """, unsafe_allow_html=True)

st.divider()
st.markdown("<div class='footer'>© 2025 Water Quality Analyzer | Designed by <b>Vatsal Negi</b></div>", unsafe_allow_html=True)
